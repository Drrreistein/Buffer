# Auto Generated IK for FANUC CRX10L with IKFast

## Build
g++ ikcrx.cpp -o ikcrx.out

## Use
./ikcrx.out q1 q2 q3 q4 q5 q6 # seed joint values


for example:
./ikcrx.out 0 0.1 0.2 0.3 0 0.1
